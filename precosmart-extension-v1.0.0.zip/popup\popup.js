// PreçoSmart - Popup Especializado em Eletrônicos
// Lojas: Mercado Livre, Shopee, KaBuM!, Amazon, AliExpress

const formatBRL = (val) =>
  Number(val).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

// Catálogo focado 100% em Eletrônicos com cotações nas 5 lojas
const electronicsCatalog = [
  {
    title: 'Smartphone Apple iPhone 15 128GB',
    category: 'Smartphones',
    quotes: [
      { store: 'KaBuM!', price: 4699.90, link: 'https://www.kabum.com.br/busca/iphone-15' },
      { store: 'Mercado Livre', price: 4749.00, link: 'https://lista.mercadolivre.com.br/iphone-15' },
      { store: 'Shopee', price: 4799.00, link: 'https://shopee.com.br/search?keyword=iphone%2015' },
      { store: 'Amazon', price: 4899.00, link: 'https://www.amazon.com.br/s?k=iphone+15' },
      { store: 'AliExpress', price: 5120.00, link: 'https://pt.aliexpress.com/wholesale?SearchText=iphone+15' }
    ]
  },
  {
    title: 'Console PlayStation 5 Slim 1TB',
    category: 'Games & Consoles',
    quotes: [
      { store: 'Shopee', price: 3499.00, link: 'https://shopee.com.br/search?keyword=ps5' },
      { store: 'Amazon', price: 3599.00, link: 'https://www.amazon.com.br/s?k=ps5' },
      { store: 'Mercado Livre', price: 3649.00, link: 'https://lista.mercadolivre.com.br/ps5' },
      { store: 'KaBuM!', price: 3699.90, link: 'https://www.kabum.com.br/busca/ps5' },
      { store: 'AliExpress', price: 3890.00, link: 'https://pt.aliexpress.com/wholesale?SearchText=ps5' }
    ]
  },
  {
    title: 'Placa de Vídeo GeForce RTX 4060 8GB GDDR6',
    category: 'Hardware & PC',
    quotes: [
      { store: 'KaBuM!', price: 1899.90, link: 'https://www.kabum.com.br/busca/rtx-4060' },
      { store: 'AliExpress', price: 1949.00, link: 'https://pt.aliexpress.com/wholesale?SearchText=rtx+4060' },
      { store: 'Mercado Livre', price: 1999.00, link: 'https://lista.mercadolivre.com.br/rtx-4060' },
      { store: 'Amazon', price: 2049.00, link: 'https://www.amazon.com.br/s?k=rtx+4060' },
      { store: 'Shopee', price: 2099.00, link: 'https://shopee.com.br/search?keyword=rtx%204060' }
    ]
  },
  {
    title: 'Smart TV 55" 4K UHD Samsung Crystal',
    category: 'TV & Vídeo',
    quotes: [
      { store: 'Amazon', price: 2499.00, link: 'https://www.amazon.com.br/s?k=smart+tv+55+samsung' },
      { store: 'Mercado Livre', price: 2549.00, link: 'https://lista.mercadolivre.com.br/smart-tv-55-samsung' },
      { store: 'Shopee', price: 2599.00, link: 'https://shopee.com.br/search?keyword=smart%20tv%2055%20samsung' },
      { store: 'KaBuM!', price: 2699.90, link: 'https://www.kabum.com.br/busca/smart-tv-55-samsung' },
      { store: 'AliExpress', price: 2890.00, link: 'https://pt.aliexpress.com/wholesale?SearchText=smart+tv+55+samsung' }
    ]
  },
  {
    title: 'Monitor Gamer LG UltraGear 27" 144Hz 1ms IPS',
    category: 'Monitores',
    quotes: [
      { store: 'KaBuM!', price: 1099.90, link: 'https://www.kabum.com.br/busca/ultragear-27' },
      { store: 'Mercado Livre', price: 1189.00, link: 'https://lista.mercadolivre.com.br/ultragear-27' },
      { store: 'Shopee', price: 1199.00, link: 'https://shopee.com.br/search?keyword=ultragear%2027' },
      { store: 'Amazon', price: 1249.00, link: 'https://www.amazon.com.br/s?k=ultragear+27' },
      { store: 'AliExpress', price: 1290.00, link: 'https://pt.aliexpress.com/wholesale?SearchText=ultragear+27' }
    ]
  },
  {
    title: 'SSD NVMe M.2 1TB Kingston / Crucial',
    category: 'Armazenamento',
    quotes: [
      { store: 'AliExpress', price: 289.00, link: 'https://pt.aliexpress.com/wholesale?SearchText=ssd+nvme+1tb' },
      { store: 'Shopee', price: 319.00, link: 'https://shopee.com.br/search?keyword=ssd%20nvme%201tb' },
      { store: 'KaBuM!', price: 349.90, link: 'https://www.kabum.com.br/busca/ssd-nvme-1tb' },
      { store: 'Mercado Livre', price: 359.00, link: 'https://lista.mercadolivre.com.br/ssd-nvme-1tb' },
      { store: 'Amazon', price: 379.00, link: 'https://www.amazon.com.br/s?k=ssd+nvme+1tb' }
    ]
  },
  {
    title: 'Console Nintendo Switch OLED 64GB',
    category: 'Games & Consoles',
    quotes: [
      { store: 'Shopee', price: 1999.00, link: 'https://shopee.com.br/search?keyword=nintendo%20switch%20oled' },
      { store: 'Mercado Livre', price: 2089.00, link: 'https://lista.mercadolivre.com.br/nintendo-switch-oled' },
      { store: 'Amazon', price: 2149.00, link: 'https://www.amazon.com.br/s?k=nintendo+switch+oled' },
      { store: 'KaBuM!', price: 2199.90, link: 'https://www.kabum.com.br/busca/nintendo-switch-oled' },
      { store: 'AliExpress', price: 2280.00, link: 'https://pt.aliexpress.com/wholesale?SearchText=nintendo+switch+oled' }
    ]
  }
];

// Gerador de links de busca direta nas 5 lojas
function getStoreSearchUrl(store, term) {
  const enc = encodeURIComponent(term);
  switch (store) {
    case 'Mercado Livre':
      return `https://lista.mercadolivre.com.br/${enc}`;
    case 'Shopee':
      return `https://shopee.com.br/search?keyword=${enc}`;
    case 'KaBuM!':
      return `https://www.kabum.com.br/busca/${enc}`;
    case 'Amazon':
      return `https://www.amazon.com.br/s?k=${enc}`;
    case 'AliExpress':
      return `https://pt.aliexpress.com/wholesale?SearchText=${enc}`;
    default:
      return '#';
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  // Navegação por Abas
  const tabBtnCurrent = document.getElementById('tab-btn-current');
  const tabBtnSearch = document.getElementById('tab-btn-search');
  const tabBtnAlerts = document.getElementById('tab-btn-alerts');

  const tabCurrent = document.getElementById('tab-current');
  const tabSearch = document.getElementById('tab-search');
  const tabAlerts = document.getElementById('tab-alerts');

  function switchTab(activeBtn, activeTabEl) {
    [tabBtnCurrent, tabBtnSearch, tabBtnAlerts].forEach((b) => b.classList.remove('active'));
    [tabCurrent, tabSearch, tabAlerts].forEach((t) => t.classList.add('hidden'));

    activeBtn.classList.add('active');
    activeTabEl.classList.remove('hidden');
  }

  tabBtnCurrent.addEventListener('click', () => switchTab(tabBtnCurrent, tabCurrent));
  tabBtnSearch.addEventListener('click', () => {
    switchTab(tabBtnSearch, tabSearch);
    renderSearchResults('');
  });
  tabBtnAlerts.addEventListener('click', () => {
    switchTab(tabBtnAlerts, tabAlerts);
    renderWatchlist();
  });

  const testStoreLink = document.getElementById('open-test-store-link');
  testStoreLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('test-store.html') });
  });

  const exportBtn = document.getElementById('btn-export-watchlist');
  if (exportBtn) {
    exportBtn.addEventListener('click', async () => {
      const { watchlist = [] } = await chrome.storage.local.get('watchlist');
      if (watchlist.length === 0) {
        alert('Nenhum item salvo para exportar.');
        return;
      }
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(watchlist, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', 'precosmart-alertas.json');
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    });
  }

  updateAlertsCount();
  await loadCurrentPageProduct();

  const searchInput = document.getElementById('search-input');
  searchInput.placeholder = 'Buscar iPhone, PS5, RTX 4060, TV, Monitor...';
  searchInput.addEventListener('input', (e) => {
    renderSearchResults(e.target.value);
  });
});

async function loadCurrentPageProduct() {
  const container = document.getElementById('detected-container');

  try {
    const { lastDetectedProduct } = await chrome.storage.local.get('lastDetectedProduct');

    if (lastDetectedProduct) {
      renderDetectedProduct(lastDetectedProduct, container);
      return;
    }

    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">📱</div>
        <h3>Nenhum eletrônico detectado nesta aba</h3>
        <p style="margin-bottom: 12px;">
          Navegue em <strong>Mercado Livre, Shopee, KaBuM, Amazon</strong> ou <strong>AliExpress</strong> para comparar automaticamente!
        </p>
        <button id="btn-test-page-hero" class="btn-track" style="display: inline-block; width: auto; padding: 8px 16px;">
          Abrir Loja de Demonstração
        </button>
      </div>
    `;

    document.getElementById('btn-test-page-hero')?.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('test-store.html') });
    });
  } catch (err) {
    container.innerHTML = `<div class="empty-state"><p>Erro: ${err.message}</p></div>`;
  }
}

function renderDetectedProduct(product, container) {
  // Achar no catálogo se existir
  const itemInCatalog = electronicsCatalog.find((c) =>
    product.title.toLowerCase().includes(c.title.toLowerCase().substring(0, 15))
  );

  let quotes;
  if (itemInCatalog) {
    quotes = [...itemInCatalog.quotes];
  } else {
    // Gerar comparativo estimado nas 5 lojas
    const basePrice = product.price;
    quotes = [
      { store: 'KaBuM!', price: Number((basePrice * 0.96).toFixed(2)), link: getStoreSearchUrl('KaBuM!', product.title) },
      { store: 'Shopee', price: Number((basePrice * 0.98).toFixed(2)), link: getStoreSearchUrl('Shopee', product.title) },
      { store: 'Mercado Livre', price: Number((basePrice * 0.99).toFixed(2)), link: getStoreSearchUrl('Mercado Livre', product.title) },
      { store: 'Amazon', price: basePrice, link: getStoreSearchUrl('Amazon', product.title) },
      { store: 'AliExpress', price: Number((basePrice * 1.04).toFixed(2)), link: getStoreSearchUrl('AliExpress', product.title) }
    ];
  }

  quotes.sort((a, b) => a.price - b.price);
  const lowestPrice = quotes[0].price;

  let quotesHtml = quotes
    .map((q) => {
      const isCheapest = q.price === lowestPrice;
      return `
        <div class="store-row ${isCheapest ? 'cheapest' : ''}">
          <div class="store-row-name">
            <span>${q.store}</span>
            ${isCheapest ? '<span class="store-tag-cheapest">Menor</span>' : ''}
          </div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <span class="store-row-price">${formatBRL(q.price)}</span>
            ${q.link ? `<a href="${q.link}" target="_blank" style="color: #64748b; text-decoration: none;" title="Abrir loja">↗</a>` : ''}
          </div>
        </div>
      `;
    })
    .join('');

  container.innerHTML = `
    <div class="product-card">
      <div class="product-card-title">${product.title}</div>
      <div class="product-card-store">Detectado em: <strong>${product.store || 'Loja'}</strong> (${formatBRL(product.price)})</div>
      
      <div style="font-size: 11px; font-weight: 700; color: #475569; margin-bottom: 6px; text-transform: uppercase;">
        Comparação nas 5 Lojas de Eletrônicos:
      </div>
      <div class="store-comparison-list">
        ${quotesHtml}
      </div>

      <button class="btn-track" id="btn-save-current">
        ★ Salvar Alerta de Preço
      </button>
    </div>
  `;

  document.getElementById('btn-save-current').addEventListener('click', async () => {
    const { watchlist = [] } = await chrome.storage.local.get('watchlist');
    const updated = [
      {
        title: product.title,
        price: product.price,
        store: product.store || 'Online',
        date: new Date().toLocaleDateString('pt-BR')
      },
      ...watchlist.filter((w) => w.title !== product.title)
    ];

    await chrome.storage.local.set({ watchlist: updated });
    updateAlertsCount();
    alert('Eletrônico salvo na sua lista de alertas!');
  });
}

function renderSearchResults(query) {
  const container = document.getElementById('search-results');
  const term = query.toLowerCase().trim();

  const filtered = term
    ? electronicsCatalog.filter((c) => c.title.toLowerCase().includes(term) || c.category.toLowerCase().includes(term))
    : electronicsCatalog;

  if (filtered.length === 0) {
    // Opção de buscar nas 5 lojas mesmo que não esteja no catálogo pré-cadastrado
    container.innerHTML = `
      <div class="empty-state">
        <p style="margin-bottom: 12px;">Nenhum produto cadastrado com "${query}".</p>
        <p style="font-size: 11px; color: #475569; margin-bottom: 10px;">
          Pesquise "<strong>${query}</strong>" diretamente nas 5 lojas:
        </p>
        <div style="display: flex; flex-direction: column; gap: 6px; text-align: left;">
          <a href="${getStoreSearchUrl('Mercado Livre', query)}" target="_blank" class="store-row" style="text-decoration: none; color: #0f172a;">
            <span>Buscar no <strong>Mercado Livre</strong></span> <span>↗</span>
          </a>
          <a href="${getStoreSearchUrl('Shopee', query)}" target="_blank" class="store-row" style="text-decoration: none; color: #0f172a;">
            <span>Buscar na <strong>Shopee</strong></span> <span>↗</span>
          </a>
          <a href="${getStoreSearchUrl('KaBuM!', query)}" target="_blank" class="store-row" style="text-decoration: none; color: #0f172a;">
            <span>Buscar na <strong>KaBuM!</strong></span> <span>↗</span>
          </a>
          <a href="${getStoreSearchUrl('Amazon', query)}" target="_blank" class="store-row" style="text-decoration: none; color: #0f172a;">
            <span>Buscar na <strong>Amazon</strong></span> <span>↗</span>
          </a>
          <a href="${getStoreSearchUrl('AliExpress', query)}" target="_blank" class="store-row" style="text-decoration: none; color: #0f172a;">
            <span>Buscar no <strong>AliExpress</strong></span> <span>↗</span>
          </a>
        </div>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered
    .map((item) => {
      const quotes = [...item.quotes].sort((a, b) => a.price - b.price);
      const lowest = quotes[0];
      const highest = quotes[quotes.length - 1];
      const diff = highest.price - lowest.price;

      return `
        <div class="product-card">
          <div class="product-card-title">${item.title}</div>
          <div class="product-card-store" style="color: #059669; font-weight: 700;">
            Menor preço: ${formatBRL(lowest.price)} (${lowest.store})
          </div>
          <div style="font-size: 11px; color: #64748b; margin-bottom: 6px;">
            Diferença de até ${formatBRL(diff)} entre as lojas
          </div>

          <div class="store-comparison-list">
            ${quotes
              .map(
                (q) => `
              <div class="store-row ${q.price === lowest.price ? 'cheapest' : ''}">
                <span class="store-row-name">${q.store}</span>
                <div style="display: flex; align-items: center; gap: 6px;">
                  <span class="store-row-price">${formatBRL(q.price)}</span>
                  ${q.link ? `<a href="${q.link}" target="_blank" style="color: #64748b; text-decoration: none;" title="Abrir oferta">↗</a>` : ''}
                </div>
              </div>
            `
              )
              .join('')}
          </div>
        </div>
      `;
    })
    .join('');
}

async function renderWatchlist() {
  const container = document.getElementById('watchlist-container');
  const { watchlist = [] } = await chrome.storage.local.get('watchlist');

  if (watchlist.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⭐</div>
        <h3>Sua lista de alertas está vazia</h3>
        <p>Clique em "Salvar Alerta" em qualquer eletrônico para monitorá-lo aqui.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = watchlist
    .map(
      (item, idx) => `
      <div class="product-card" style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div class="product-card-title">${item.title}</div>
          <div style="font-size: 11px; color: #64748b;">
            Salvo por <strong>${formatBRL(item.price)}</strong> na ${item.store}
          </div>
        </div>
        <button data-index="${idx}" class="btn-remove-item" style="background: none; border: none; color: #ef4444; font-size: 16px; cursor: pointer; padding: 4px;">
          🗑️
        </button>
      </div>
    `
    )
    .join('');

  container.querySelectorAll('.btn-remove-item').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const index = parseInt(btn.dataset.index, 10);
      watchlist.splice(index, 1);
      await chrome.storage.local.set({ watchlist });
      updateAlertsCount();
      renderWatchlist();
    });
  });
}

async function updateAlertsCount() {
  const { watchlist = [] } = await chrome.storage.local.get('watchlist');
  const el = document.getElementById('alert-count');
  if (el) el.innerText = watchlist.length;
}
